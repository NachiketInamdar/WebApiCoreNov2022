﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DependencyInjectionDemo.Models
{
    public class EmployeeRepository : IEmployeeRepository
    {
        static List<Employee> employees = null;

        static EmployeeRepository()
        {
            employees = new List<Employee>()
            {
                new Employee{EmployeeId = 1001, FirstName = "Sachin", LastName = "Tendulkar", Salary = 50000},
                new Employee{EmployeeId = 1002, FirstName = "Pusarla", LastName = "Sindhu", Salary = 50000}
            };
        }
        public Employee AddEmployee(Employee employee)
        {
            employees.Add(employee);
            return employee;
        }

        public int DeleteEmployee(int employeeId)
        {
            Employee existingEmp = employees.FirstOrDefault(emp => emp.EmployeeId == employeeId);
            if (existingEmp != null)
            {
                employees.Remove(existingEmp);
                return employeeId;
            }
            return 0;
        }

        public Employee GetEmployee(int employeeId)
        {

            Employee existingEmp = employees.FirstOrDefault(emp => emp.EmployeeId == employeeId);
            return existingEmp;
        }

        public List<Employee> GetEmployees()
        {
            return employees;
        }

        public Employee UpdateEmployee(int employeeId, Employee employee)
        {
            Employee existingEmp = employees.FirstOrDefault(emp => emp.EmployeeId == employeeId);
            if(existingEmp!=null)
            {
                existingEmp.FirstName = employee.FirstName;
                existingEmp.LastName = employee.LastName;
                existingEmp.Salary = employee.Salary;
                return employee;
            }
            return null;
        }
    }
}
