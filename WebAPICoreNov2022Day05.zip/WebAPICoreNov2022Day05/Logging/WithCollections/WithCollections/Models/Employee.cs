﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WithCollections.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        [Required(ErrorMessage ="Name is mandatory")]
        public string Name { get; set; }
        [Range(1,double.MaxValue,ErrorMessage ="Salary is required and should be greater than 0")]
        public double Salary { get; set; }
    }
}
