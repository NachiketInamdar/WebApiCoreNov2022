﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AttributeRoutingDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        [HttpGet("notedited")]
        public IEnumerable<string> Get()
        {
            return new string[] { "Value1", "Value2" };
        }

        [HttpGet("{id}")]
        public IEnumerable<string> Get(int id)
        {
            return new string[] { id.ToString(), "Value1", "Value2" };
        }
    }
}
