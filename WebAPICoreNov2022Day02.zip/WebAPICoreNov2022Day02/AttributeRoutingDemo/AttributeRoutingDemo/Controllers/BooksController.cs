﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AttributeRoutingDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        [HttpGet("{id:int}/author/{authorid:int}")]
        public IEnumerable<string> GetDetails(int id, int authorid)
        {
            return new string[]
            {
                "GetBookDetails.V2.value1",
                "GetBookDetails.V2.value2"
            };
        }
    }
}
