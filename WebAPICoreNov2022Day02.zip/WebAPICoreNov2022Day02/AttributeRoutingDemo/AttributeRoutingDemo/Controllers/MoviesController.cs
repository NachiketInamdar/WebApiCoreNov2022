﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AttributeRoutingDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        //[HttpGet("{id:int}")]
        [Route("RetrieveMovieName/{id:int}")]
        public IEnumerable<string> Get(int id)
        {
            return new string[] {
                "V1.value1",
                "V1.value2"
            };
        }
        [HttpGet("{id:alpha}")]
        public IEnumerable<string> Get(string id)
        {
            return new string[] {
                "V2.value1",
                "V2.value2"
            };
        }
    }
}
